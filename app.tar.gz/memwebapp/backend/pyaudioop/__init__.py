import audioop
from audioop import *
